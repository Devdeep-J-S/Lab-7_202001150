package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class P5_JuintTesting {

	@Test
    public void testValidPrefix() {
        assertTrue(Problem5.prefix("ab", "abcdef"));
        assertTrue(Problem5.prefix("hello", "hello world"));
    }

    @Test
    public void testInvalidPrefix() {
        assertFalse(Problem5.prefix("abc", "def"));
        assertFalse(Problem5.prefix("world", "hello"));
    }

    @Test
    public void testPrefixWithEmptyString() {
        assertTrue(Problem5.prefix("", "hello"));
    }

    @Test
    public void testPrefixWithOneChar() {
        assertTrue(Problem5.prefix("a", "abcdef"));
        assertTrue(Problem5.prefix("h", "hello world"));
        assertFalse(Problem5.prefix("z", "hello"));
    }

    @Test
    public void testPrefixWithIdenticalString() {
        assertTrue(Problem5.prefix("hello", "hello"));
    }

    @Test
    public void testPrefixWithStringOfLength100() {
        assertTrue(Problem5.prefix("abc", "abc" + "d".repeat(97)));
//        assertFalse(Problem5.prefix("abc", "abc" + "d".repeat(98)));
    }

}
