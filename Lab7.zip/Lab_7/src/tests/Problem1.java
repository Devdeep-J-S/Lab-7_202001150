package tests;

public class Problem1 {
	static int linearSearch(int v, int a[]) {
	    int i = 0;
	    while (i < a.length) {
	        if (a[i] == v)
	            return (i);
	        i++;
	    }
	    return (-1);
	}
}
