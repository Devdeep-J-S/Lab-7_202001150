package tests;

public class Problem3 {
	static int binarySearch(int a[], int v) {
	    int lo, mid, hi;
	    lo = 0;
	    hi = a.length - 1;
	    while (lo <= hi) {
	        mid = (lo + hi) / 2;
	        if (v == a[mid])
	            return (mid);
	        else if (v < a[mid])
	            hi = mid - 1;
	        else
	            lo = mid + 1;

	    }
	    return (-1);
	}
}
