package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class P6_JunitTesting {

	private final int EQUILATERAL = 0;
    private final int ISOSCELES = 1;
    private final int SCALENE = 2;
    private final int INVALID = 3;

    @Test
    public void testEquilateral1() {
        assertEquals(EQUILATERAL, Problem6.triangle(3, 3, 3));
    }

    @Test
    public void testIsosceles1() {
        assertEquals(ISOSCELES, Problem6.triangle(2, 2, 3));
        assertEquals(ISOSCELES, Problem6.triangle(2, 3, 2));
        assertEquals(ISOSCELES, Problem6.triangle(3, 2, 2));
    }

    @Test
    public void testScalene1() {
        assertEquals(SCALENE, Problem6.triangle(3, 4, 5));
        assertEquals(SCALENE, Problem6.triangle(2, 3, 4));
        assertEquals(SCALENE, Problem6.triangle(4, 5, 7));
    }

    @Test
    public void testInvalid1() {
        assertEquals(INVALID, Problem6.triangle(1, 2, 3));
        assertEquals(INVALID, Problem6.triangle(2, 4, 2));
    }
    
    @Test
    public void testEquilateral() {
        assertEquals(0, Problem6.triangle(2, 2, 2));
        assertEquals(0, Problem6.triangle(3, 3, 3));
        assertEquals(0, Problem6.triangle(10, 10, 10));
    }

    @Test
    public void testIsosceles() {
        assertEquals(1, Problem6.triangle(2, 2, 3));
        assertEquals(1, Problem6.triangle(2, 3, 2));
        assertEquals(1, Problem6.triangle(3, 2, 2));
        assertEquals(1, Problem6.triangle(10, 10, 12));
        assertEquals(1, Problem6.triangle(10, 12, 10));
        assertEquals(1, Problem6.triangle(12, 10, 10));
    }

    @Test
    public void testScalene() {
        assertEquals(2, Problem6.triangle(3, 4, 5));
        assertEquals(2, Problem6.triangle(5, 12, 13));
        assertEquals(2, Problem6.triangle(7, 8, 10));
    }

    @Test
    public void testInvalid() {
        assertEquals(3, Problem6.triangle(1, 2, 3));
        assertEquals(3, Problem6.triangle(2, 3, 1));
        assertEquals(3, Problem6.triangle(3, 1, 2));
        assertEquals(3, Problem6.triangle(0, 1, 1));
        assertEquals(3, Problem6.triangle(1, 0, 1));
        assertEquals(3, Problem6.triangle(1, 1, 0));
    }

    @Test
    public void testBoundaryScalene() {
        assertEquals(2, Problem6.triangle(2147483645, 2147483646, 2147483647));
        assertEquals(3, Problem6.triangle(2147483647, 2147483647, 2147483647));
    }

    @Test
    public void testBoundaryIsosceles() {
        assertEquals(1, Problem6.triangle(1, 2147483647, 2147483647));
        assertEquals(1, Problem6.triangle(2147483647, 1, 2147483647));
        assertEquals(1, Problem6.triangle(2147483647, 2147483647, 1));
        assertEquals(3, Problem6.triangle(0, 2147483647, 2147483647));
    }

    @Test
    public void testBoundaryEquilateral() {
        assertEquals(0, Problem6.triangle(2147483647, 2147483647, 2147483647));
    }

    @Test
    public void testBoundaryRightAngle() {
        assertEquals(3, Problem6.triangle(1, 1, 1));
        assertEquals(3, Problem6.triangle(3, 4, 5));
        assertEquals(3, Problem6.triangle(5, 12, 13));
        assertEquals(0, Problem6.triangle(5, 5, (int) (5 * Math.sqrt(2))));
    }



}
