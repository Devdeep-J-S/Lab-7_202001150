package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class P4_JunitTesting {
	final int EQUILATERAL = 0;
	final int ISOSCELES = 1;
	final int SCALENE = 2;
	final int INVALID = 3;
	 @Test
	    void testEquilateraltriangle() {
	        int result = Problem4.triangle(3, 3, 3);
	        assertEquals(0, result);
	    }
	    
	    @Test
	    void testIsoscelesProblem4WithAAndBEqual() {
	        int result = Problem4.triangle(5, 5, 3);
	        assertEquals(1, result);
	    }
	    
	    @Test
	    void testIsoscelesProblem4WithBAndCEqual() {
	        int result = Problem4.triangle(3, 5, 5);
	        assertEquals(1, result);
	    }
	    
	    @Test
	    void testIsoscelesProblem4WithAAndCEqual() {
	        int result = Problem4.triangle(5, 3, 5);
	        assertEquals(1, result);
	    }
	    
	    @Test
	    void testScalenetriangle() {
	        int result = Problem4.triangle(3, 4, 5);
	        assertEquals(2, result);
	    }
	    
	    @Test
	    void testInvalidProblem4WithAEqualToSumOfBC() {
	        int result = Problem4.triangle(5, 3, 2);
	        assertEquals(3, result);
	    }
	    
	    @Test
	    void testInvalidProblem4WithBEqualToSumOfAC() {
	        int result = Problem4.triangle(3, 5, 2);
	        assertEquals(3, result);
	    }
	    
	    @Test
	    void testInvalidProblem4WithCEqualToSumOfAB() {
	        int result = Problem4.triangle(2, 3, 5);
	        assertEquals(3, result);
	    }
	    
	    @Test
	    void testInvalidProblem4WithAEqualToZero() {
	        int result = Problem4.triangle(0, 3, 5);
	        assertEquals(3, result);
	    }
	    
	    @Test
	    void testInvalidProblem4WithBEqualToZero() {
	        int result = Problem4.triangle(3, 0, 5);
	        assertEquals(3, result);
	    }
	    
	    @Test
	    void testInvalidProblem4WithCEqualToZero() {
	        int result = Problem4.triangle(3, 5, 0);
	        assertEquals(3, result);
	    }
}

