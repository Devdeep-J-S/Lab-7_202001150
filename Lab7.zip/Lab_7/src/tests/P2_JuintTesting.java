package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class P2_JuintTesting {

    @Test
    public void countItem() {
        assertEquals(0, Problem2.countItem(0, new int[] {1, 2, 3}));
        assertEquals(1, Problem2.countItem(1, new int[] {1, 2, 3}));
        assertEquals(2, Problem2.countItem(2, new int[] {1, 2, 2, 3}));
        assertEquals(1, Problem2.countItem(-1, new int[] {-1, 0, 1, 2, 3}));
        assertEquals(2, Problem2.countItem(100, new int[] {100, 100, 200, 300}));
        assertEquals(0, Problem2.countItem(0, new int[] {}));
    }
}
