package tests;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class P3_JunitTesting {
		@Test
		public void binarySearch() {
			// Equivalence Partitioning:
			// Group 1: Empty array
			int[] a1 = {};
			assertEquals(-1, Problem3.binarySearch(a1, 1));
			
			// Group 2: Array with one element
			int[] a2 = {1};
			assertEquals(0, Problem3.binarySearch(a2, 1));
			assertEquals(-1, Problem3.binarySearch(a2, 2));
			
			// Group 3: Array with two elements
			int[] a3 = {1, 2};
			assertEquals(0, Problem3.binarySearch(a3, 1));
			assertEquals(1, Problem3.binarySearch(a3, 2));
			assertEquals(-1, Problem3.binarySearch(a3, 3));
			
			// Group 4: Array with more than two elements
			int[] a4 = {1, 2, 3, 4, 5};
			assertEquals(0, Problem3.binarySearch(a4, 1));
			assertEquals(2, Problem3.binarySearch(a4, 3));
			assertEquals(4, Problem3.binarySearch(a4, 5));
			assertEquals(-1, Problem3.binarySearch(a4, 6));
			
			// Boundary Value Analysis:
//			assertEquals(0, Problem3.binarySearch(a4, -2147483648)); // Lowest value
//			assertEquals(4, Problem3.binarySearch(a4, 2147483647)); // Highest value
//			assertEquals(-1, Problem3.binarySearch(a4, -2147483649)); // One less than the lowest value
//			assertEquals(-1, Problem3.binarySearch(a4, 2147483648)); // One more than the highest value
			assertEquals(2, Problem3.binarySearch(a4, 3)); // Midpoint value
		}
	}