package tests;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class JunitTesting {
    @Test
    void testEquivalencePartitioning() {
        int[] arr1 = {1, 2, 3, 4, 5};
        assertEquals(4, Problem1.linearSearch(5, arr1));
        assertEquals(0, Problem1.linearSearch(1, arr1));
        assertEquals(-1, Problem1.linearSearch(6, arr1));
        int[] arr2 = {1};
        assertEquals(0, Problem1.linearSearch(1, arr2));
        int[] arr3 = {};
        assertEquals(-1, Problem1.linearSearch(1, arr3));
        int[] arr4 = {-1, -2, -3, -4};
        assertEquals(-1, Problem1.linearSearch(-5, arr4));
    }

    @Test
    void testBoundaryValueAnalysis() {
        int[] arr1 = {1, 2, 3, 4, 5};
        assertEquals(0, Problem1.linearSearch(1, arr1));
        assertEquals(4, Problem1.linearSearch(5, arr1));
        int[] arr2 = {-1, 0, 1};
        assertEquals(0, Problem1.linearSearch(-1, arr2));
        assertEquals(2, Problem1.linearSearch(1, arr2));
        assertEquals(1, Problem1.linearSearch(0, arr2));
        int[] arr3 = {99, 100, 101};
        assertEquals(1, Problem1.linearSearch(100, arr3));
    }
    
    @Test
    public void countItem() {
        assertEquals(0, Problem2.countItem(0, new int[] {1, 2, 3}));
        assertEquals(1, Problem2.countItem(1, new int[] {1, 2, 3}));
        assertEquals(2, Problem2.countItem(2, new int[] {1, 2, 2, 3}));
        assertEquals(1, Problem2.countItem(-1, new int[] {-1, 0, 1, 2, 3}));
        assertEquals(2, Problem2.countItem(100, new int[] {100, 100, 200, 300}));
        assertEquals(0, Problem2.countItem(0, new int[] {}));
    }
    

}
